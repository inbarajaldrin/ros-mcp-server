"""Gripper-ONLY bringup: husarion-native RG2 state publisher + the CAD-arc driver.

The declared sim gripper backend. Composes with the prismatic bringup's other legs
(launch_ur = the arm, launch_rosbridge, launch_isaacsim = the twin) — it deliberately
does NOT bring up ur_robot_driver or rviz (those are separate concerns owned elsewhere).
For the full standalone twin (arm + gripper + rviz) use ur5e_rg2_sim.launch.py instead.

  ros2 launch onrobot_rg2_sim_control gripper.launch.py

Gripper hangs off tool0 through the quick-changer (+90/-90 mount + 15.92mm weld baked in
the URDF: reach +Z, jaws flange-X). The driver maps CONTACT-width commands -> the
rg2_gripper_joint through the CAD arc model (rg2_arc).
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node

PKG_SHARE = get_package_share_directory("onrobot_rg2_sim_control")
URDF = os.path.join(PKG_SHARE, "urdf", "rg2_husarion_native.urdf")
DRIVER = os.path.join(PKG_SHARE, "scripts", "rg2_gripper_driver.py")


def generate_launch_description():
    with open(URDF) as f:
        rg2_description = f.read()

    rg2_rsp = Node(
        package="robot_state_publisher", executable="robot_state_publisher",
        namespace="rg2ref", name="rg2_state_publisher",
        parameters=[{"robot_description": rg2_description}],
    )

    gripper_driver = ExecuteProcess(
        cmd=["python3", DRIVER], name="rg2_gripper_driver", output="screen")

    return LaunchDescription([rg2_rsp, gripper_driver])
