import os
from glob import glob

from setuptools import find_packages, setup

package_name = 'onrobot_rg2_sim_control'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
        (os.path.join('share', package_name, 'urdf'), glob('urdf/*')),
        (os.path.join('share', package_name, 'meshes'), glob('meshes/*')),
        (os.path.join('share', package_name, 'rviz'), glob('rviz/*')),
        (os.path.join('share', package_name, 'scripts'), glob('scripts/*.py')),
    ],
    install_requires=['setuptools', 'pyyaml'],
    zip_safe=True,
    maintainer='Aldrin Inbaraj',
    maintainer_email='aldrininbaraj@gmail.com',
    description='OnRobot RG2 CAD-grounded sim gripper (rg2_arc + Isaac contact-width backend + husarion-native URDF + driver/launch).',
    license='TODO',
    tests_require=['pytest'],
    # No console_scripts: the launch file runs scripts/rg2_gripper_driver.py from
    # the installed share/ (faithful to the original). The python module
    # (rg2_arc, rg2_sim_backend) is importable as `onrobot_rg2_sim_control`.
    entry_points={},
)
